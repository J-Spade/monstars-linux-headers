#define UTS_RELEASE "3.11.0-12-generic"
